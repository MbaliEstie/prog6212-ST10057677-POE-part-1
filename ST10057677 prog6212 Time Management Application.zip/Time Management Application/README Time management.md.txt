Title: Time Management Application
Using the Application:
In the application window, you can add modules for the semester by entering module details such as code, name, credits, class hours, number of weeks, and start date. Click the "Add Module" button to add a module.
You can also record the number of hours you spend working on a specific module on a certain date. Enter the date and hours worked, then click the "Display study hours" button.
The application will display a list of modules with information about self-study hours per week, recorded hours, and remaining hours for the current week.
