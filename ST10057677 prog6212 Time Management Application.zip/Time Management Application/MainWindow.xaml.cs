﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using System.Xml.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices.ComTypes;
using Class;

namespace Time_Management_Application
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    { 

        public List<Module> Minfo = new List<Module>();

    public List<Declarations> Mhours = new List<Declarations>();
    
        public MainWindow()
    {
        InitializeComponent();
    }
    private void Button_Click(object sender, RoutedEventArgs e)
    {
            // this code displays the module name and hours on the list view
            LVSH.Items.Clear();

            foreach (Module Mdata in Minfo)
            {
                if (Mdata.modulenme == "")
                {
                    Mdata.Equals(null);
                }
                LVSH.Items.Add(Mdata);
            }

        }


    private void txtWks_TextChanged(object sender, TextChangedEventArgs e)
    {

    }

    private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
    {

    }

    private void btnErase_Click(object sender, RoutedEventArgs e)
    {
        LVSH.Items.Clear();
    }
    

        

       
        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnAM_Click_1(object sender, RoutedEventArgs e)
        {
            if (txtMC.Text != "" && txtMN.Text != "" && txtCred.Text != "" && txtCH.Text != "" && txtWks.Text != "")
            {

                //this code stored the information in the textboxes in  variables
                string ModCode = txtMC.Text;
                string ModName = txtMN.Text;
                int ModCredits = int.Parse(txtCred.Text);
                int ModHours = int.Parse(txtCH.Text);
                int Weeks = int.Parse(txtWks.Text);
                DateTime StartDate = DPstart.SelectedDate ?? DateTime.Now;
                double StudyHours = ((ModCredits * 10) / Weeks) - ModHours;

                // this code adds the object properties to the getters and setters 
                Module Mdata = new Module(ModCode, ModName, ModCredits, ModHours, Weeks, StudyHours, StartDate);

                // this code adeds the object to a list
                Minfo.Add(Mdata);

                //this code clears the text boxes
                txtMC.Text = "";
                txtMN.Text = "";
                txtCred.Text = "";
                txtCH.Text = "";
                txtWks.Text = "";

                MessageBox.Show("Captured successfully");
            }
            else
            {
                MessageBox.Show("Please make sure that you have filled in every field.");
            }

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            // this code records the hours and date that the user has input and performs the needed calculation
            Module selectedModule = LVSH.SelectedItem as Module;

            if (txtHS.Text != "")
            {
                if (selectedModule != null)
                {

                    int hoursSpent = int.Parse(txtHS.Text);
                    DateTime dateofwork = DPSDUp.SelectedDate ?? DateTime.Now;
                    selectedModule.HoursSpent += hoursSpent;
                    double hoursupdate = selectedModule.modulesh - selectedModule.HoursSpent;
                    if (hoursupdate <= 0)
                    {
                        MessageBox.Show("Congratulations!! You have successfully completed your hours ;)");
                        selectedModule.modulesh = 0;
                    }
                    else
                    {
                        selectedModule.modulesh = hoursupdate;
                        MessageBox.Show("Updated Successfully");
                    }


                    txtHS.Clear();
                    LVSH.Items.Refresh();

                    Declarations Mupdate = new Declarations(hoursSpent, dateofwork);
                    Mhours.Add(Mupdate);



                }


            }
            else
            {
                MessageBox.Show("Please select a module on the list view and make sure that you have filled in all of the fields.");
            }


        }
    }
}


